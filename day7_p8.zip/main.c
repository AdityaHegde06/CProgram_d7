/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.
(hour-49)
***************************************************************************
/*cdetermine overtime pay of 10 employee*/

#include <stdio.h>

int main()
{
    float  otpay;
    int hour,i=1;
    while(i<=10)
    {
        printf("\nEnter no of hours worked ");
        scanf("%d",&hour);
        if(hour>=40)
        otpay=(hour-40)*120;
        else
        otpay=0;
        printf("Hours=%d\nOvertime pay=Rs.%f\n",hour,otpay);
        i++;
    }

    return 0;
}
