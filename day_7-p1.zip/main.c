
/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
/*calculation of simple interest for 3 sets of p,n,and r*/

#include <stdio.h>

int main()
{
int p,n,count;
float r,si;
count=1;
while(count<=3)
{
    printf("Enter values of p,n and r ");
    scanf("%d%d%f",&p,&n,&r);
    si=p*n*r/100;
    printf("Simple interest=Rs%f\n",si);
    count=count+1;
    
}

    return 0;
}
